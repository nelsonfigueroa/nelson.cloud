<!DOCTYPE html>
<html>
<head><title>Admin Login</title></head>
<body>
<h1>Login</h1>
<form action="login.php" method="post">
<label>Username: <input type="text" name="username"></label><br>
<label>Password: <input type="password" name="password"></label><br>
<button type="submit">Login</button>
</form>
</body>
</html>