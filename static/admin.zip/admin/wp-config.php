<?php
// WordPress config
define('DB_NAME', 'nelsoncloud');
define('DB_USER', 'admin');
define('DB_PASSWORD', 'averysecretpassword999');
define('DB_HOST', 'localhost');
define('AUTH_KEY',         'zM3)7@2Q#VwKy^GNR+T0!fxpL4B8dJqZvWmSPajXk1csouO^F5YElI6tUHng9Cr');
define('SECURE_AUTH_KEY',  'W#1mx+gIYvj$98KzPhdE4TfkVqlDC7sQnoLXy^2StRbwMJZOU*ae50)HuFNpcG3r');
define('LOGGED_IN_KEY',    'lf6ArGHWmD0!qJeBUVNsMxT9Oz#PbzjvktoX+1cyFRCZ3IKnY7wSu8h@E54dpSlg');
define('NONCE_KEY',        'ZwPbmV^uUqRX7HkjISQtDYGLNApKOoe@v6JxCr18*ElHdWF#sgM0Z9ntfCz25yB+');
define('AUTH_SALT',        'GC&UkLjNxRz98IHr02qByvE+Vht+ZdwDKnplh!OoXJ#4fALs13EW6@cbmSu7TgFQ');
define('SECURE_AUTH_SALT', '7koJhXy!6BEnagUlxqGZz2RYr*3pQcT#Sd0C5eVbFOimLMI&KWfNvHt9Du1wPj+@');
define('LOGGED_IN_SALT',   'AVX57mpZJz1LwIbsoYSkWahDfjHtguq2GlMrOydrKXxC*CF0TvN9Q^eEU#Pn38+6');
define('NONCE_SALT',       'oyGCAx+7ELIBVKX9sYHZplJV@1qmk04eSzgWb8fQj2tUnwTROdhDNvFcsMrPu3!a');
?>
