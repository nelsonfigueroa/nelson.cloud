CREATE TABLE users (
  id INT PRIMARY KEY,
  username VARCHAR(50),
  password VARCHAR(255)
);
INSERT INTO users VALUES (1, 'admin', '5f4dcc3b5aa765d61d8327deb882cf99'); -- password
