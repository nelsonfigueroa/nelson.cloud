<?php
define('DB_NAME', 'nelsoncloud');
define('DB_USER', 'admin');
define('DB_PASSWORD', 'averysecretpassword999'); // change this
?>
